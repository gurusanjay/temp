#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"

class VehicleOdometryPublisher : public rclcpp::Node
{
public:
    VehicleOdometryPublisher() : Node("vehicle_odometry_publisher")
    {
        inspvax_subscription_ = this->create_subscription<std_msgs::msg::String>(
            "inspvax", 10, std::bind(&VehicleOdometryPublisher::inspvax_callback, this, std::placeholders::_1));

        imu_subscription_ = this->create_subscription<std_msgs::msg::String>(
            "imu", 10, std::bind(&VehicleOdometryPublisher::imu_callback, this, std::placeholders::_1));

        odometry_publisher_ = this->create_publisher<std_msgs::msg::String>("vehicleodometry", 10);
    }

private:
    void inspvax_callback(const std_msgs::msg::String::SharedPtr msg)
    {
        inspvax_data_ = msg->data;
        publish_odometry();
    }

    void imu_callback(const std_msgs::msg::String::SharedPtr msg)
    {
        imu_data_ = msg->data;
        publish_odometry();
    }

    void publish_odometry()
    {
        if (!inspvax_data_.empty() && !imu_data_.empty())
        {
            auto odometry_msg = std_msgs::msg::String();
            odometry_msg.data = "Processed Vehicle Odometry: " + inspvax_data_ + " | " + imu_data_;
            odometry_publisher_->publish(odometry_msg);

            RCLCPP_INFO(this->get_logger(), "Published vehicle odometry: '%s'", odometry_msg.data.c_str());
        }
    }

    std::string inspvax_data_;
    std::string imu_data_;
    rclcpp::Subscription<std_msgs::msg::String>::SharedPtr inspvax_subscription_;
    rclcpp::Subscription<std_msgs::msg::String>::SharedPtr imu_subscription_;
    rclcpp::Publisher<std_msgs::msg::String>::SharedPtr odometry_publisher_;
};

int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<VehicleOdometryPublisher>());
    rclcpp::shutdown();
    return 0;
}
