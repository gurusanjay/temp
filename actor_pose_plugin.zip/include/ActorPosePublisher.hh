#ifndef ACTOR_POSE_PUBLISHER_HH
#define ACTOR_POSE_PUBLISHER_HH

#include <gz/sim/System.hh>
#include <gz/transport/Node.hh>

namespace gz { namespace sim {
class ActorPosePublisher : public System,
                           public ISystemConfigure,
                           public ISystemPostUpdate
{
public:
    void Configure(const Entity &, const std::shared_ptr<const sdf::Element> &, EntityComponentManager &, EventManager &) override;
    void PostUpdate(const UpdateInfo &, const EntityComponentManager &) override;

private:
    transport::Node node;
    transport::Node::Publisher posePub;
    Entity entity;
};
}}
#endif
