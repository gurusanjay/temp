#include <gz/sim/System.hh>
#include <gz/sim/Model.hh>
#include <gz/sim/components/Pose.hh>
#include <gz/sim/components/Actor.hh>
#include <gz/transport/Node.hh>
#include <gz/math/Pose3.hh>

using namespace gz;
using namespace sim;

class ActorPosePublisher : public System,
                           public ISystemConfigure,
                           public ISystemPostUpdate
{
public:
    transport::Node node;
    transport::Node::Publisher posePub;
    Entity actorEntity;

    void Configure(const Entity &_entity, const std::shared_ptr<const sdf::Element> &, EntityComponentManager &_ecm, EventManager &) override
    {
        if (!_ecm.EntityHasComponent<components::Actor>(_entity))
        {
            gzerr << "Entity is not an actor." << std::endl;
            return;
        }

        this->actorEntity = _entity;
        posePub = node.Advertise<msgs::Pose>("/actor_pose");
    }

    void PostUpdate(const UpdateInfo &, const EntityComponentManager &_ecm) override
    {
        auto poseComp = _ecm.Component<components::Pose>(this->actorEntity);
        if (!poseComp)
            return;

        math::Pose3d pose = poseComp->Data();

        // Create and publish the pose message
        msgs::Pose msg;
        msg.mutable_position()->set_x(pose.Pos().X());
        msg.mutable_position()->set_y(pose.Pos().Y());
        msg.mutable_position()->set_z(pose.Pos().Z());
        msg.mutable_orientation()->set_x(pose.Rot().X());
        msg.mutable_orientation()->set_y(pose.Rot().Y());
        msg.mutable_orientation()->set_z(pose.Rot().Z());
        msg.mutable_orientation()->set_w(pose.Rot().W());

        posePub.Publish(msg);
    }
};

// Register plugin
GZ_ADD_PLUGIN(ActorPosePublisher,
              System,
              ISystemConfigure,
              ISystemPostUpdate)

GZ_ADD_PLUGIN_ALIAS(ActorPosePublisher, "gz::sim::ActorPosePublisher")
