#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"

class InspvaxImuPublisher : public rclcpp::Node
{
public:
    InspvaxImuPublisher() : Node("inspvax_imu_publisher")
    {
        inspvax_publisher_ = this->create_publisher<std_msgs::msg::String>("inspvax", 10);
        imu_publisher_ = this->create_publisher<std_msgs::msg::String>("imu", 10);
        timer_ = this->create_wall_timer(
            std::chrono::milliseconds(500), std::bind(&InspvaxImuPublisher::publish_messages, this));
    }

private:
    void publish_messages()
    {
        auto inspvax_msg = std_msgs::msg::String();
        inspvax_msg.data = "Inspvax data";
        inspvax_publisher_->publish(inspvax_msg);

        auto imu_msg = std_msgs::msg::String();
        imu_msg.data = "IMU data";
        imu_publisher_->publish(imu_msg);

        RCLCPP_INFO(this->get_logger(), "Published inspvax and imu messages");
    }

    rclcpp::Publisher<std_msgs::msg::String>::SharedPtr inspvax_publisher_;
    rclcpp::Publisher<std_msgs::msg::String>::SharedPtr imu_publisher_;
    rclcpp::TimerBase::SharedPtr timer_;
};

int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<InspvaxImuPublisher>());
    rclcpp::shutdown();
    return 0;
}
