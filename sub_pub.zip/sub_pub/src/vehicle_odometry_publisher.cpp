#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"
#include "message_filters/subscriber.h"
#include "message_filters/time_synchronizer.h"
#include "message_filters/sync_policies/exact_time.h"

class VehicleOdometryPublisher : public rclcpp::Node
{
public:
    VehicleOdometryPublisher() : Node("vehicle_odometry_publisher")
    {
        inspvax_subscriber_ = std::make_shared<message_filters::Subscriber<std_msgs::msg::String>>(this, "inspvax");
        imu_subscriber_ = std::make_shared<message_filters::Subscriber<std_msgs::msg::String>>(this, "imu");

        sync_ = std::make_shared<message_filters::Synchronizer<SyncPolicy>>(
            SyncPolicy(10), *inspvax_subscriber_, *imu_subscriber_);

        sync_->registerCallback(std::bind(&VehicleOdometryPublisher::callback, this, std::placeholders::_1, std::placeholders::_2));

        odometry_publisher_ = this->create_publisher<std_msgs::msg::String>("vehicleodometry", 10);
    }

private:
    void callback(const std_msgs::msg::String::ConstSharedPtr inspvax_msg, const std_msgs::msg::String::ConstSharedPtr imu_msg)
    {
        auto odometry_msg = std_msgs::msg::String();
        odometry_msg.data = "Processed Vehicle Odometry: " + inspvax_msg->data + " | " + imu_msg->data;

        odometry_publisher_->publish(odometry_msg);
        RCLCPP_INFO(this->get_logger(), "Published synchronized vehicle odometry: '%s'", odometry_msg.data.c_str());
    }

    using SyncPolicy = message_filters::sync_policies::ExactTime<std_msgs::msg::String, std_msgs::msg::String>;

    std::shared_ptr<message_filters::Subscriber<std_msgs::msg::String>> inspvax_subscriber_;
    std::shared_ptr<message_filters::Subscriber<std_msgs::msg::String>> imu_subscriber_;
    std::shared_ptr<message_filters::Synchronizer<SyncPolicy>> sync_;
    rclcpp::Publisher<std_msgs::msg::String>::SharedPtr odometry_publisher_;
};

int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<VehicleOdometryPublisher>());
    rclcpp::shutdown();
    return 0;
}
